-- Path: CorePackages.Packages._Index.RbxDesignFoundations-31ab8d40-4.0.11.RbxDesignFoundations.KidsClassic
return {
	["Dark"] = require(script.Dark),
	["Light"] = require(script.Light)
}