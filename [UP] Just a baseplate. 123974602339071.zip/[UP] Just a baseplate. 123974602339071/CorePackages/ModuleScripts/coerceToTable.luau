-- Path: CorePackages.Packages._Index.Collections.Collections.Map.coerceToTable
local v1 = script.Parent
local v2 = v1.Parent
local v3 = v2.Parent
local v_u_4 = require(v1.Map)
local v_u_5 = require(v3.InstanceOf)
local v_u_6 = require(v2.Array.reduce)
require(v3.ES7Types)
return function(p7) -- name: coerceToTable
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_6
	if v_u_5(p7, v_u_4) then
		return v_u_6(p7:entries(), function(p8, p9)
			p8[p9[1]] = p9[2]
			return p8
		end, {})
	else
		return p7
	end
end