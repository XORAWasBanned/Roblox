-- Path: CorePackages.Packages._Index.Collections.Collections.Object.entries
local v1 = script.Parent.Parent.Parent
require(v1.ES7Types)
return function(p2)
	local v3 = p2 ~= nil
	assert(v3, "cannot get entries from a nil value")
	local v4 = typeof(p2)
	local v5 = {}
	if v4 == "table" then
		for v6, v7 in pairs(p2) do
			table.insert(v5, { v6, v7 })
		end
		return v5
	else
		if v4 == "string" then
			for v8 = 1, string.len(p2) do
				v5[v8] = { tostring(v8), (string.sub(p2, v8, v8)) }
			end
		end
		return v5
	end
end