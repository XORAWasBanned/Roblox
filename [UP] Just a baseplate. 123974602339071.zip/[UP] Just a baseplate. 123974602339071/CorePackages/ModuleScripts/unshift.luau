-- Path: CorePackages.Packages._Index.Collections.Collections.Array.unshift
local v_u_1 = _G.__DEV__
local v2 = script.Parent
local v3 = v2.Parent.Parent
local v_u_4 = require(v2.isArray)
require(v3.ES7Types)
return function(p5, ...)
	-- upvalues: (copy) v_u_1, (copy) v_u_4
	if v_u_1 and not v_u_4(p5) then
		error(string.format("Array.unshift called on non-array %s", (typeof(p5))))
	end
	local v6 = select("#", ...)
	if v6 > 0 then
		for v7 = v6, 1, -1 do
			local v8 = select(v7, ...)
			table.insert(p5, 1, v8)
		end
	end
	return #p5
end