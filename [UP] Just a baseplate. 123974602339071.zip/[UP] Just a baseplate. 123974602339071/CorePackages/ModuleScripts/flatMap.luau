-- Path: CorePackages.Packages._Index.Collections.Collections.Array.flatMap
local v_u_1 = _G.__DEV__
local v2 = script.Parent
local v3 = v2.Parent.Parent
local v_u_4 = require(v2.flat)
local v_u_5 = require(v2.map)
require(v3.ES7Types)
return function(p6, p7, p8) -- name: flatMap
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_5
	if v_u_1 then
		if typeof(p6) ~= "table" then
			error(string.format("Array.flatMap called on %s", (typeof(p6))))
		end
		if typeof(p7) ~= "function" then
			error("callback is not a function")
		end
	end
	return v_u_4(v_u_5(p6, p7, p8))
end