-- Path: CorePackages.Packages._Index.MomentsCommon.Dash
local v1 = script.Parent.Parent.Parent._Index
return require(v1.Dash.Dash)