-- Path: CorePackages.Packages._Index.MarkdownCore.React
local v1 = script.Parent.Parent.Parent._Index
return require(v1.React.React)