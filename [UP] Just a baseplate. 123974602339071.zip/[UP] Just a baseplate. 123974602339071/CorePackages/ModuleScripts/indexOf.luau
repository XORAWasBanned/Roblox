-- Path: CorePackages.Packages._Index.Collections.Collections.Array.indexOf
local v1 = script.Parent.Parent.Parent
require(v1.ES7Types)
return function(p2, p3, p4)
	local v5 = p4 or 1
	local v6 = #p2
	if v5 < 1 then
		local v7 = v6 - math.abs(v5)
		v5 = math.max(v7, 1)
	end
	for v8 = v5, v6 do
		if p2[v8] ~= p3 then
			continue
		end
		return v8
	end
	return -1
end