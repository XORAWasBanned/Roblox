-- Path: CorePackages.Packages._Index.Collections.Collections.Array.filter
-- https://lua.expert

local __DEV__ = _G.__DEV__

require(script.Parent.Parent.Parent.ES7Types)

return function(p1, p2, p3) -- line: 27
    -- upvalues: __DEV__ (copy)
    if __DEV__ then
        if typeof(p1) ~= "table" then
            error(string.format("Array.filter called on %s", (typeof(p1))))
        end

        if typeof(p2) ~= "function" then
            error("callback is not a function")
        end
    end

    local v1 = #p1
    local t1 = {}

    if p3 ~= nil then
        local n2 = 1

        for i = 1, v1 do
            local v3 = p1[i]

            if v3 ~= nil and p2(p3, v3, i, p1) then
                t1[n2] = v3
                n2 += 1
            end
        end
    else
        local n1 = 1

        for i = 1, v1 do
            local v2 = p1[i]

            if v2 ~= nil and p2(v2, i, p1) then
                t1[n1] = v2
                n1 += 1
            end
        end
    end

    return t1
end
