-- Path: CorePackages.Packages._Index.LuauPolyfill-31ab8d40-1.2.3.Timers
local v1 = script.Parent.Parent.Parent._Index
return require(v1.Timers.Timers)