-- Path: CorePackages.Packages._Index.LuaSocialLibrariesDeps.RoduxFriends
local v1 = script.Parent.Parent.Parent._Index
return require(v1.RoduxFriends.RoduxFriends)